#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QTimer>
#include <QImage>
#include <QPushButton>
#include <QDebug>
#include <QPalette>
#include <QDateTime> // Added for timestamp
#include <QLineEdit> // Added for user input
#include <QDir> // Include QDir for working with directories
#include <QFileDialog> // Include QFileDialog for choosing a folder
#include <QMessageBox> // Include QMessageBox for displaying a message box
#include <QInputDialog>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

cv::VideoCapture capture;
cv::Mat frame;

cv::VideoCapture capture2;
cv::Mat frame2;

cv::VideoCapture capture3;
cv::Mat frame3;

cv::VideoCapture capture4;
cv::Mat frame4;

cv::VideoCapture capture5;
cv::Mat frame5;

bool camera1On = false;
bool camera2On = false;
bool camera3On = false;
bool camera4On = false;
bool camera5On = false;

void captureImage()
{
    capture >> frame;
    if (!frame.empty()) {
        // Generate a unique filename using timestamp
        QString currentDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss");
        
        // Get the project's directory path
        QString projectDirPath = QDir::currentPath();
        
        // Set the temporary directory path within the project's directory
        QString tempDirPath = projectDirPath + QDir::separator() + "tmpimg";
        
        // Create the temporary directory if it doesn't exist
        QDir tempDir(tempDirPath);
        if (!tempDir.exists()) {
            tempDir.mkpath(".");
        }
        
        // Set the file path with the temporary directory
        QString filePath = tempDirPath + QDir::separator() + currentDateTime + "1" + ".jpg";
        
        // Save the image using OpenCV
        cv::imwrite(filePath.toStdString(), frame);
    }
}

void captureImage2()
{
    capture2 >> frame2;
    if (!frame2.empty()) {
        // Generate a unique filename using timestamp
        QString currentDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss");
        
        // Get the project's directory path
        QString projectDirPath = QDir::currentPath();
        
        // Set the temporary directory path within the project's directory
        QString tempDirPath = projectDirPath + QDir::separator() + "tmpimg";
        
        // Create the temporary directory if it doesn't exist
        QDir tempDir(tempDirPath);
        if (!tempDir.exists()) {
            tempDir.mkpath(".");
        }
        
        // Set the file path with the temporary directory
        QString filePath = tempDirPath + QDir::separator() + currentDateTime + "2" + ".jpg";
        
        // Save the image using OpenCV
        cv::imwrite(filePath.toStdString(), frame2);
    }
}

void captureImage3()
{
    capture3 >> frame3;
    if (!frame3.empty()) {
        // Generate a unique filename using timestamp
        QString currentDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss");
        
        // Get the project's directory path
        QString projectDirPath = QDir::currentPath();
        
        // Set the temporary directory path within the project's directory
        QString tempDirPath = projectDirPath + QDir::separator() + "tmpimg";
        
        // Create the temporary directory if it doesn't exist
        QDir tempDir(tempDirPath);
        if (!tempDir.exists()) {
            tempDir.mkpath(".");
        }
        
        // Set the file path with the temporary directory
        QString filePath = tempDirPath + QDir::separator() + currentDateTime + "3" + ".jpg";
        
        // Save the image using OpenCV
        cv::imwrite(filePath.toStdString(), frame3);
    }
}

void captureImage4()
{
    capture4 >> frame4;
    if (!frame4.empty()) {
        // Generate a unique filename using timestamp
        QString currentDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss");
        
        // Get the project's directory path
        QString projectDirPath = QDir::currentPath();
        
        // Set the temporary directory path within the project's directory
        QString tempDirPath = projectDirPath + QDir::separator() + "tmpimg";
        
        // Create the temporary directory if it doesn't exist
        QDir tempDir(tempDirPath);
        if (!tempDir.exists()) {
            tempDir.mkpath(".");
        }
        
        // Set the file path with the temporary directory
        QString filePath = tempDirPath + QDir::separator() + currentDateTime + "4" + ".jpg";
        
        // Save the image using OpenCV
        cv::imwrite(filePath.toStdString(), frame4);
    }
}

void captureImage5()
{
    capture5 >> frame5;
    if (!frame5.empty()) {
        // Generate a unique filename using timestamp
        QString currentDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss");
        
        // Get the project's directory path
        QString projectDirPath = QDir::currentPath();
        
        // Set the temporary directory path within the project's directory
        QString tempDirPath = projectDirPath + QDir::separator() + "tmpimg";
        
        // Create the temporary directory if it doesn't exist
        QDir tempDir(tempDirPath);
        if (!tempDir.exists()) {
            tempDir.mkpath(".");
        }
        
        // Set the file path with the temporary directory
        QString filePath = tempDirPath + QDir::separator() + currentDateTime + "5" + ".jpg";
        
        // Save the image using OpenCV
        cv::imwrite(filePath.toStdString(), frame5);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool isRecording = false;
cv::VideoWriter writer;

bool isRecording2 = false;
cv::VideoWriter writer2;

bool isRecording3 = false;
cv::VideoWriter writer3;

bool isRecording4 = false;
cv::VideoWriter writer4;

bool isRecording5 = false;
cv::VideoWriter writer5;

void startRecording() {
    if (!isRecording) {
        QString currentDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss");
        QString projectDirPath = QDir::currentPath();
        QString tempDirPath = projectDirPath + QDir::separator() + "tmpvideo";
        
        // Create the temporary directory if it doesn't exist
        QDir tempDir(tempDirPath);
        if (!tempDir.exists()) {
            tempDir.mkpath(".");
        }
        QString filePath = tempDirPath + QDir::separator() + currentDateTime + "*.avi";
        if (!filePath.isEmpty()) {
            int codec = cv::VideoWriter::fourcc('M', 'J', 'P', 'G');
            double fps = 30.0; // Set a fixed frame rate (e.g., 30 fps)
            cv::Size frameSize(static_cast<int>(capture.get(cv::CAP_PROP_FRAME_WIDTH)), static_cast<int>(capture.get(cv::CAP_PROP_FRAME_HEIGHT)));
            writer.open(filePath.toStdString(), codec, fps, frameSize);

            if (writer.isOpened()) {
                isRecording = true;
            }
        }
    }
}

void startRecording2() {
    if (!isRecording2) {
        QString currentDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss");
        QString projectDirPath = QDir::currentPath();
        QString tempDirPath = projectDirPath + QDir::separator() + "tmpvideo";
        
        // Create the temporary directory if it doesn't exist
        QDir tempDir(tempDirPath);
        if (!tempDir.exists()) {
            tempDir.mkpath(".");
        }
        QString filePath = tempDirPath + QDir::separator() + currentDateTime + "*.avi";
        if (!filePath.isEmpty()) {
            int codec = cv::VideoWriter::fourcc('M', 'J', 'P', 'G');
            double fps = 30.0; // Set a fixed frame rate (e.g., 30 fps)
            cv::Size frameSize(static_cast<int>(capture2.get(cv::CAP_PROP_FRAME_WIDTH)), static_cast<int>(capture2.get(cv::CAP_PROP_FRAME_HEIGHT)));
            writer2.open(filePath.toStdString(), codec, fps, frameSize);

            if (writer2.isOpened()) {
                isRecording2 = true;
            }
        }
    }
}

void startRecording3() {
    if (!isRecording3) {
        QString currentDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss");
        QString projectDirPath = QDir::currentPath();
        QString tempDirPath = projectDirPath + QDir::separator() + "tmpvideo";
        
        // Create the temporary directory if it doesn't exist
        QDir tempDir(tempDirPath);
        if (!tempDir.exists()) {
            tempDir.mkpath(".");
        }
        QString filePath = tempDirPath + QDir::separator() + currentDateTime + "*.avi";
        if (!filePath.isEmpty()) {
            int codec = cv::VideoWriter::fourcc('M', 'J', 'P', 'G');
            double fps = 30.0; // Set a fixed frame rate (e.g., 30 fps)
            cv::Size frameSize(static_cast<int>(capture3.get(cv::CAP_PROP_FRAME_WIDTH)), static_cast<int>(capture3.get(cv::CAP_PROP_FRAME_HEIGHT)));
            writer3.open(filePath.toStdString(), codec, fps, frameSize);

            if (writer3.isOpened()) {
                isRecording3 = true;
            }
        }
    }
}

void startRecording4() {
    if (!isRecording4) {
        QString currentDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss");
        QString projectDirPath = QDir::currentPath();
        QString tempDirPath = projectDirPath + QDir::separator() + "tmpvideo";
        
        // Create the temporary directory if it doesn't exist
        QDir tempDir(tempDirPath);
        if (!tempDir.exists()) {
            tempDir.mkpath(".");
        }
        QString filePath = tempDirPath + QDir::separator() + currentDateTime + "*.avi";
        if (!filePath.isEmpty()) {
            int codec = cv::VideoWriter::fourcc('M', 'J', 'P', 'G');
            double fps = 30.0; // Set a fixed frame rate (e.g., 30 fps)
            cv::Size frameSize(static_cast<int>(capture4.get(cv::CAP_PROP_FRAME_WIDTH)), static_cast<int>(capture4.get(cv::CAP_PROP_FRAME_HEIGHT)));
            writer4.open(filePath.toStdString(), codec, fps, frameSize);

            if (writer4.isOpened()) {
                isRecording4 = true;
            }
        }
    }
}

void startRecording5() {
    if (!isRecording5) {
        QString currentDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss");
        QString projectDirPath = QDir::currentPath();
        QString tempDirPath = projectDirPath + QDir::separator() + "tmpvideo";
        
        // Create the temporary directory if it doesn't exist
        QDir tempDir(tempDirPath);
        if (!tempDir.exists()) {
            tempDir.mkpath(".");
        }
        QString filePath = tempDirPath + QDir::separator() + currentDateTime + "*.avi";
        if (!filePath.isEmpty()) {
            int codec = cv::VideoWriter::fourcc('M', 'J', 'P', 'G');
            double fps = 30.0; // Set a fixed frame rate (e.g., 30 fps)
            cv::Size frameSize(static_cast<int>(capture5.get(cv::CAP_PROP_FRAME_WIDTH)), static_cast<int>(capture5.get(cv::CAP_PROP_FRAME_HEIGHT)));
            writer5.open(filePath.toStdString(), codec, fps, frameSize);

            if (writer5.isOpened()) {
                isRecording5 = true;
            }
        }
    }
}

void stopRecording() {
    if (isRecording) {
        isRecording = false;
        writer.release();
    }
}

void stopRecording2() {
    if (isRecording2) {
        isRecording2 = false;
        writer2.release();
    }
}

void stopRecording3() {
    if (isRecording3) {
        isRecording3 = false;
        writer3.release();
    }
}

void stopRecording4() {
    if (isRecording4) {
        isRecording4 = false;
        writer4.release();
    }
}

void stopRecording5() {
    if (isRecording5) {
        isRecording5 = false;
        writer5.release();
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static int datasetCount = 1; // Static variable to keep track of dataset count

void newFolder()
{
    
    QString projectDirPath = QDir::currentPath();
    QString baseDirPath = projectDirPath + QDir::separator() + "datasets";

    // Construct the dataset folder name
    QString folderName = "dataset" + QString::number(datasetCount);
    QString folderPath = baseDirPath + QDir::separator() + folderName;
    
    // Create the dataset folder
    QDir folderDir(folderPath);
    folderDir.mkpath(".");

    // Increment the dataset count for the next folder
    datasetCount++;
}

void deleteFolder(QWidget* parent)
{
    // Prompt the user to select the dataset folder
    QString selectedFolder = QFileDialog::getExistingDirectory(parent, "Select Dataset Folder", QDir::currentPath());

    if (!selectedFolder.isEmpty()) {
        // Confirm the deletion with the user
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(parent, "Confirm Deletion", "Are you sure you want to delete the selected dataset folder?", QMessageBox::Yes | QMessageBox::No);

        if (reply == QMessageBox::Yes) {
            // Delete the dataset folder
            QDir folderDir(selectedFolder);
            if (folderDir.exists()) {
                if (folderDir.removeRecursively()) {
                    QMessageBox::information(parent, "Deletion", "Dataset folder deleted successfully.");
                } else {
                    QMessageBox::critical(parent, "Error", "Failed to delete dataset folder.");
                }
            } else {
                QMessageBox::warning(parent, "Warning", "Dataset folder not found.");
            }
        }
    }
}

void mergeFolders(QWidget* parent)
{
    // Prompt the user to select the source and destination dataset folders
    QString sourceFolder = QFileDialog::getExistingDirectory(parent, "Select Source Dataset Folder", QDir::currentPath());
    QString destinationFolder = QFileDialog::getExistingDirectory(parent, "Select Destination Dataset Folder", QDir::currentPath());

    if (!sourceFolder.isEmpty() && !destinationFolder.isEmpty()) {
        // Confirm the merge operation with the user
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(parent, "Confirm Merge", "Are you sure you want to merge the datasets?", QMessageBox::Yes | QMessageBox::No);

        if (reply == QMessageBox::Yes) {
            // Iterate over the files in the source folder and move them to the destination folder
            QDir sourceDir(sourceFolder);
            QDir destinationDir(destinationFolder);
            QStringList files = sourceDir.entryList(QDir::Files);
            foreach (const QString& file, files) {
                QString sourceFilePath = sourceFolder + QDir::separator() + file;
                QString destinationFilePath = destinationFolder + QDir::separator() + file;
                QFile::rename(sourceFilePath, destinationFilePath);
            }

            // Remove the empty source folder
            if (sourceDir.removeRecursively()) {
                QMessageBox::information(parent, "Merge", "Dataset folders merged successfully.");
            } else {
                QMessageBox::critical(parent, "Error", "Failed to merge dataset folders.");
            }
        }
    }
}

void copyFolder(QWidget* parent)
{
    // Prompt the user to select the source and destination folders
    QString sourceFolder = QFileDialog::getExistingDirectory(parent, "Select Source Folder", QDir::currentPath());
    QString destinationFolder = QFileDialog::getExistingDirectory(parent, "Select Destination Folder", QDir::currentPath());

    if (!sourceFolder.isEmpty() && !destinationFolder.isEmpty()) {
        // Confirm the copy operation with the user
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(parent, "Confirm Copy", "Are you sure you want to copy the files?", QMessageBox::Yes | QMessageBox::No);

        if (reply == QMessageBox::Yes) {
            QDir sourceDir(sourceFolder);
            QDir destinationDir(destinationFolder);
            QStringList files = sourceDir.entryList(QDir::Files);

            foreach (const QString& file, files) {
                QString sourceFilePath = sourceFolder + QDir::separator() + file;
                QString destinationFilePath = destinationFolder + QDir::separator() + file;

                if (!QFile::copy(sourceFilePath, destinationFilePath)) {
                    QMessageBox::critical(parent, "Error", "Failed to copy file: " + sourceFilePath);
                    return;
                }
            }

            QMessageBox::information(parent, "Copy", "Files copied successfully.");
        }
    }
}

void processImages()
{
    // Prompt the user to select the folder
    QString folderPath = QFileDialog::getExistingDirectory(nullptr, "Select Folder", QDir::currentPath());

    if (!folderPath.isEmpty()) {
        QDir folderDir(folderPath);
        QStringList filters;
        filters << "*.jpg" << "*.jpeg" << "*.png"; // Add more image formats if needed
        folderDir.setNameFilters(filters);

        QStringList imageFiles = folderDir.entryList();
        foreach (const QString& imageFile, imageFiles) {
            QString imagePath = folderPath + QDir::separator() + imageFile;
            cv::Mat image = cv::imread(imagePath.toStdString());

            if (!image.empty()) {
                cv::Mat rotatedImage;
                cv::Mat flippedImage;

                // Apply rotation (90 degrees clockwise)
                cv::rotate(image, rotatedImage, cv::ROTATE_90_CLOCKWISE);

                // Apply flipping (horizontal flip)
                cv::flip(image, flippedImage, 1);

                // Extract the directory path from the image file path
                QString imageDirPath = QFileInfo(imagePath).dir().absolutePath();

                // Generate new filenames
                QString rotatedFileName = "rotated_" + imageFile;
                QString flippedFileName = "flipped_" + imageFile;

                // Construct the output file paths using the original directory path
                QString rotatedImagePath = imageDirPath + QDir::separator() + rotatedFileName;
                QString flippedImagePath = imageDirPath + QDir::separator() + flippedFileName;

                cv::imwrite(rotatedImagePath.toStdString(), rotatedImage);
                cv::imwrite(flippedImagePath.toStdString(), flippedImage);
            }
        }

        QMessageBox::information(nullptr, "Image Processing", "Image processing completed successfully.");
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void openVideo(QWidget* parent)
{
    // Prompt the user to select the video file
    QString videoFilePath = QFileDialog::getOpenFileName(parent, "Open Video", QDir::currentPath(), "Video Files (*.avi *.mp4)");

    if (!videoFilePath.isEmpty()) {
        // Create a VideoCapture object to read the video file
        cv::VideoCapture videoCapture(videoFilePath.toStdString());

        if (videoCapture.isOpened()) {
            cv::Mat frame;

            // Create a QLabel widget to display the video frames
            QLabel* videoLabel = new QLabel(parent);
            videoLabel->setGeometry(5, 190, 350, 300);
            videoLabel->show();

            // Read and display video frames until the end of the video
            while (videoCapture.read(frame)) {
                // Convert the OpenCV frame to a QImage for display
                QImage qImage(frame.data, frame.cols, frame.rows, frame.step, QImage::Format_RGB888);
                QPixmap pixmap = QPixmap::fromImage(qImage.rgbSwapped());

                // Scale the pixmap to fit the label dimensions
                pixmap = pixmap.scaled(videoLabel->size(), Qt::KeepAspectRatio);

                // Set the pixmap on the label
                videoLabel->setPixmap(pixmap);

                // Process events to update the label display
                QApplication::processEvents();
            }

            // Release the video capture object
            videoCapture.release();

            // Delete the video label widget
            delete videoLabel;
        }
        else {
            QMessageBox::critical(parent, "Error", "Failed to open video file.");
        }
    }
}


void openVideoWithInterval(QWidget* parent, int captureInterval)
{
    // Prompt the user to select the video file
    QString videoFilePath = QFileDialog::getOpenFileName(parent, "Open Video", QDir::currentPath(), "Video Files (*.avi *.mp4)");

    if (!videoFilePath.isEmpty()) {
        // Create a VideoCapture object to read the video file
        cv::VideoCapture videoCapture(videoFilePath.toStdString());

        if (videoCapture.isOpened()) {
            cv::Mat frame;
            bool isPlaying = true;
            // Create a QLabel widget to display the video frames
            QLabel* videoLabel = new QLabel(parent);
            videoLabel->setGeometry(5, 190, 350, 300);
            videoLabel->show();
            
            int frameRate = static_cast<int>(videoCapture.get(cv::CAP_PROP_FPS));
            int frameCount = 0;
            // Read and display video frames until the end of the video or playback is paused
            while (videoCapture.read(frame)) {
                if (isPlaying) {
                    // Convert the OpenCV frame to a QImage for display
                    QImage qImage(frame.data, frame.cols, frame.rows, frame.step, QImage::Format_RGB888);
                    QPixmap pixmap = QPixmap::fromImage(qImage.rgbSwapped());

                    // Scale the pixmap to fit the label dimensions
                    pixmap = pixmap.scaled(videoLabel->size(), Qt::KeepAspectRatio);

                    // Set the pixmap on the label
                    videoLabel->setPixmap(pixmap);

                    // Process events to update the label display and respond to user input
                    QApplication::processEvents();
                }

                // Capture frames every X seconds
                    frameCount++;

                    if (frameCount % (captureInterval * frameRate) == 0) {
                    // Capture the current frame
                    cv::Mat capturedFrame;
                    videoCapture >> capturedFrame;

                    // Save the captured frame to a file
                    if (!capturedFrame.empty()) {
                        QString currentDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss");
                        QString projectDirPath = QDir::currentPath();
                        QString tempDirPath = projectDirPath + QDir::separator() + "tmpimg";
                        QDir tempDir(tempDirPath);
                        if (!tempDir.exists()) {
                            tempDir.mkpath(".");
                        }
                        QString fileName = tempDirPath + QDir::separator() + currentDateTime + ".jpg";
                        cv::imwrite(fileName.toStdString(), capturedFrame);
                        QMessageBox::information(parent, "Frame Captured", "Frame captured and saved successfully.");
                    } else {
                        QMessageBox::warning(parent, "Error", "Failed to capture frame.");
                    }
                }
            }

            videoCapture.release();
            delete videoLabel;

        } else {
            QMessageBox::warning(parent, "Error", "Failed to open video file.");
        }
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QMainWindow window;
    window.setWindowTitle("Science box");
    window.resize(1090, 900);

    QLabel bgpicture(&window);
    QPixmap image("slika_iza.png");
    QSize originalSize = image.size();
    QPixmap scaledImage = image.scaled(originalSize * 1.5);
    bgpicture.setPixmap(scaledImage);
    bgpicture.setGeometry(150, 80, 750, 750);

    QPalette palette;
    palette.setColor(QPalette::Background, Qt::white);
    window.setPalette(palette);
    window.setAutoFillBackground(true);

    QLabel logo(&window);
    QPixmap imagelogo("logo1.png");
    logo.setPixmap(imagelogo);
    logo.setGeometry(570, 820, 500, 50);

    QLabel Camera1label(&window);
    Camera1label.setGeometry(5, 190, 350, 300);

    QLabel Camera2label(&window);
    Camera2label.setGeometry(360, 190, 350, 300);

    QLabel Camera3label(&window);
    Camera3label.setGeometry(715, 190, 350, 300);

    QLabel Camera4label(&window);
    Camera4label.setGeometry(5, 495, 350, 300);

    QLabel Camera5label(&window);
    Camera5label.setGeometry(360, 495, 350, 300);

    QLabel labeltext1("Camera 1 options", &window);
    labeltext1.setGeometry(5, 5, 150, 30);
    labeltext1.setAlignment(Qt::AlignCenter);
    labeltext1.setStyleSheet("background-color: #4169E1; color: white;");

    QLabel labeltext2("Camera 2 options", &window);
    labeltext2.setGeometry(160, 5, 150, 30);
    labeltext2.setAlignment(Qt::AlignCenter);
    labeltext2.setStyleSheet("background-color: #4169E1; color: white;");

    QLabel labeltext3("Camera 3 options", &window);
    labeltext3.setGeometry(315, 5, 150, 30);
    labeltext3.setAlignment(Qt::AlignCenter);
    labeltext3.setStyleSheet("background-color: #4169E1; color: white;");

    QLabel labeltext4("Camera 4 options", &window);
    labeltext4.setGeometry(470, 5, 150, 30);
    labeltext4.setAlignment(Qt::AlignCenter);
    labeltext4.setStyleSheet("background-color: #4169E1; color: white;");

    QLabel labeltext5("Camera 5 options", &window);
    labeltext5.setGeometry(625, 5, 150, 30);
    labeltext5.setAlignment(Qt::AlignCenter);
    labeltext5.setStyleSheet("background-color: #4169E1; color: white;");

    QLabel labeltext6("Dataset options", &window);
    labeltext6.setGeometry(780, 5, 150, 30);
    labeltext6.setAlignment(Qt::AlignCenter);
    labeltext6.setStyleSheet("background-color: #4169E1; color: white;");

    QLabel labeltext7("Video options", &window);
    labeltext7.setGeometry(935, 5, 150, 30);
    labeltext7.setAlignment(Qt::AlignCenter);
    labeltext7.setStyleSheet("background-color: #4169E1; color: white;");

    QPushButton button("Open Camera", &window);
    button.setGeometry(5, 35, 150, 30);

    QPushButton Openbutton2("Open Camera", &window);
    Openbutton2.setGeometry(160, 35, 150, 30);

    QPushButton Openbutton3("Open Camera", &window);
    Openbutton3.setGeometry(315, 35, 150, 30);

    QPushButton Openbutton4("Open Camera", &window);
    Openbutton4.setGeometry(470, 35, 150, 30);

    QPushButton Openbutton5("Open Camera", &window);
    Openbutton5.setGeometry(625, 35, 150, 30);

    QPushButton captureButton("Capture picture", &window);
    captureButton.setGeometry(5, 65, 150, 30);

    QPushButton captureButton2("Capture picture", &window);
    captureButton2.setGeometry(160, 65, 150, 30);

    QPushButton captureButton3("Capture picture", &window);
    captureButton3.setGeometry(315, 65, 150, 30);

    QPushButton captureButton4("Capture picture", &window);
    captureButton4.setGeometry(470, 65, 150, 30);

    QPushButton captureButton5("Capture picture", &window);
    captureButton5.setGeometry(625, 65, 150, 30);

    QPushButton startButton("Start Recording", &window);
    startButton.setGeometry(5, 95, 150, 30);

    QPushButton stopButton("Stop Recording", &window);
    stopButton.setGeometry(5, 125, 150, 30);

    QPushButton startButton2("Start Recording", &window);
    startButton2.setGeometry(160, 95, 150, 30);

    QPushButton stopButton2("Stop Recording", &window);
    stopButton2.setGeometry(160, 125, 150, 30);

    QPushButton startButton3("Start Recording", &window);
    startButton3.setGeometry(315, 95, 150, 30);

    QPushButton stopButton3("Stop Recording", &window);
    stopButton3.setGeometry(315, 125, 150, 30);

    QPushButton startButton4("Start Recording", &window);
    startButton4.setGeometry(470, 95, 150, 30);

    QPushButton stopButton4("Stop Recording", &window);
    stopButton4.setGeometry(470, 125, 150, 30);

    QPushButton startButton5("Start Recording", &window);
    startButton5.setGeometry(625, 95, 150, 30);

    QPushButton stopButton5("Stop Recording", &window);
    stopButton5.setGeometry(625, 125, 150, 30);

    QPushButton captureDurationButton("Capture every X sec", &window);
    captureDurationButton.setGeometry(5, 155, 150, 30);

    QPushButton captureDurationButton2("Capture every X sec", &window);
    captureDurationButton2.setGeometry(160, 155, 150, 30);

    QPushButton captureDurationButton3("Capture every X sec", &window);
    captureDurationButton3.setGeometry(315, 155, 150, 30);

    QPushButton captureDurationButton4("Capture every X sec", &window);
    captureDurationButton4.setGeometry(470, 155, 150, 30);

    QPushButton captureDurationButton5("Capture every X sec", &window);
    captureDurationButton5.setGeometry(625, 155, 150, 30);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    QTimer timer;
    QObject::connect(&button, &QPushButton::clicked, [&]() {
        if (!camera1On) {
            capture.open(0);
            if (!capture.isOpened()) {
                return;
            }
            camera1On = true;
            button.setText("Close Camera");
            timer.start(30);
        } else {
            writer.release();
            capture.release();
            camera1On = false;
            button.setText("Open Camera");
            timer.stop();
            Camera1label.clear();
        }
    });

    QObject::connect(&Openbutton2, &QPushButton::clicked, [&]() {
        if (!camera2On) {
            capture2.open(3); // Open second camera (assuming it's index 1)
            if (!capture2.isOpened()) {
                return;
            }
            camera2On = true;
            Openbutton2.setText("Close Camera");
            timer.start(30); // Start timer for second camera
        } else {
            writer2.release();
            capture2.release();
            camera2On = false;
            Openbutton2.setText("Open Camera");

            // Stop timer for second camera
            timer.stop();
            Camera2label.clear();
        }
    });

    QObject::connect(&Openbutton3, &QPushButton::clicked, [&]() {
        if (!camera3On) {
            capture3.open(4); // Open second camera (assuming it's index 1)
            if (!capture3.isOpened()) {
                return;
            }
            camera3On = true;
            Openbutton3.setText("Close Camera");
            timer.start(30); // Start timer for second camera
        } else {
            writer3.release();
            capture3.release();
            camera3On = false;
            Openbutton3.setText("Open Camera");

            // Stop timer for second camera
            timer.stop();
            Camera3label.clear();
        }
    });

    QObject::connect(&Openbutton4, &QPushButton::clicked, [&]() {
        if (!camera4On) {
            capture4.open(4); // Open second camera (assuming it's index 1)
            if (!capture4.isOpened()) {
                return;
            }
            camera4On = true;
            Openbutton4.setText("Close Camera");
            timer.start(30); // Start timer for second camera
        } else {
            writer4.release();
            capture4.release();
            camera4On = false;
            Openbutton4.setText("Open Camera");

            // Stop timer for second camera
            timer.stop();
            Camera4label.clear();
        }
    });

    QObject::connect(&Openbutton5, &QPushButton::clicked, [&]() {
        if (!camera5On) {
            capture5.open(4); // Open second camera (assuming it's index 1)
            if (!capture5.isOpened()) {
                return;
            }
            camera5On = true;
            Openbutton5.setText("Close Camera");
            timer.start(30); // Start timer for second camera
        } else {
            writer5.release();
            capture5.release();
            camera5On = false;
            Openbutton5.setText("Open Camera");

            // Stop timer for second camera
            timer.stop();
            Camera5label.clear();
        }
    });

    QObject::connect(&timer, &QTimer::timeout, [&]() {
        if (camera1On && capture.isOpened()) {
            capture >> frame;

            if (frame.empty()) {
                return;
            }
            cv::cvtColor(frame, frame, cv::COLOR_BGR2RGB);

            QImage qimage(frame.data, frame.cols, frame.rows, QImage::Format_RGB888);
            Camera1label.setPixmap(QPixmap::fromImage(qimage));

            if (isRecording) {
                writer.write(frame);
            }
        }
        if (camera2On && capture2.isOpened()) {
            capture2 >> frame2;

            if (frame2.empty()) {
                return;
            }
            cv::cvtColor(frame2, frame2, cv::COLOR_BGR2RGB);

            QImage qimage2(frame2.data, frame2.cols, frame2.rows, QImage::Format_RGB888);
            Camera2label.setPixmap(QPixmap::fromImage(qimage2));

            if (isRecording2) {
                writer2.write(frame2);
            }
        }
        if (camera3On && capture3.isOpened()) {
            capture3 >> frame3;

            if (frame3.empty()) {
                return;
            }
            cv::cvtColor(frame3, frame3, cv::COLOR_BGR2RGB);

            QImage qimage3(frame3.data, frame3.cols, frame3.rows, QImage::Format_RGB888);
            Camera3label.setPixmap(QPixmap::fromImage(qimage3));

            if (isRecording3) {
                writer3.write(frame3);
            }
        }

        if (camera4On && capture4.isOpened()) {
            capture4 >> frame4;

            if (frame4.empty()) {
                return;
            }
            cv::cvtColor(frame4, frame4, cv::COLOR_BGR2RGB);

            QImage qimage4(frame4.data, frame4.cols, frame4.rows, QImage::Format_RGB888);
            Camera4label.setPixmap(QPixmap::fromImage(qimage4));

            if (isRecording4) {
                writer4.write(frame4);
            }
        }

        if (camera5On && capture5.isOpened()) {
            capture5 >> frame5;

            if (frame5.empty()) {
                return;
            }
            cv::cvtColor(frame5, frame5, cv::COLOR_BGR2RGB);

            QImage qimage5(frame5.data, frame5.cols, frame5.rows, QImage::Format_RGB888);
            Camera5label.setPixmap(QPixmap::fromImage(qimage5));

            if (isRecording5) {
                writer5.write(frame5);
            }
        }

    });

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    QObject::connect(&captureButton, &QPushButton::clicked, captureImage);
    QObject::connect(&captureButton2, &QPushButton::clicked, captureImage2);
    QObject::connect(&captureButton3, &QPushButton::clicked, captureImage3);
    QObject::connect(&captureButton4, &QPushButton::clicked, captureImage4);
    QObject::connect(&captureButton5, &QPushButton::clicked, captureImage5);

    QObject::connect(&startButton, &QPushButton::clicked, startRecording);
    QObject::connect(&stopButton, &QPushButton::clicked, stopRecording);

    QObject::connect(&startButton2, &QPushButton::clicked, startRecording2);
    QObject::connect(&stopButton2, &QPushButton::clicked, stopRecording2);

    QObject::connect(&startButton3, &QPushButton::clicked, startRecording3);
    QObject::connect(&stopButton3, &QPushButton::clicked, stopRecording3);

    QObject::connect(&startButton4, &QPushButton::clicked, startRecording4);
    QObject::connect(&stopButton4, &QPushButton::clicked, stopRecording4);

    QObject::connect(&startButton5, &QPushButton::clicked, startRecording5);
    QObject::connect(&stopButton5, &QPushButton::clicked, stopRecording5);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    bool captureDurationActive = false;
    QTimer captureDurationTimer;
    QObject::connect(&captureDurationButton, &QPushButton::clicked, [&]() {
        if (captureDurationActive) {
            captureDurationTimer.stop();
            captureDurationActive = false;
            captureDurationButton.setText("Capture every X sec");
        } else {
            // Prompt the user to enter the duration in seconds
            bool ok;
            int duration = QInputDialog::getInt(&window, "Capture Duration", "Enter duration in seconds:", 1, 1, 3600, 1, &ok);
            if (ok) {
                captureDurationTimer.start(duration * 1000); // Convert seconds to milliseconds
                captureDurationActive = true;
                captureDurationButton.setText("Stop capturing");
            }
        }
    });

    QObject::connect(&captureDurationTimer, &QTimer::timeout, captureImage);

    bool captureDurationActive2 = false;
    QTimer captureDurationTimer2;
    QObject::connect(&captureDurationButton2, &QPushButton::clicked, [&]() {
        if (captureDurationActive2) {
            captureDurationTimer2.stop();
            captureDurationActive2 = false;
            captureDurationButton2.setText("Capture every X sec");
        } else {
            // Prompt the user to enter the duration in seconds
            bool ok;
            int duration = QInputDialog::getInt(&window, "Capture Duration", "Enter duration in seconds:", 1, 1, 3600, 1, &ok);
            if (ok) {
                captureDurationTimer2.start(duration * 1000); // Convert seconds to milliseconds
                captureDurationActive2 = true;
                captureDurationButton2.setText("Stop capturing");
            }
        }
    });

    QObject::connect(&captureDurationTimer2, &QTimer::timeout, captureImage2);

    bool captureDurationActive3 = false;
    QTimer captureDurationTimer3;
    QObject::connect(&captureDurationButton3, &QPushButton::clicked, [&]() {
        if (captureDurationActive3) {
            captureDurationTimer3.stop();
            captureDurationActive3 = false;
            captureDurationButton3.setText("Capture every X sec");
        } else {
            // Prompt the user to enter the duration in seconds
            bool ok;
            int duration = QInputDialog::getInt(&window, "Capture Duration", "Enter duration in seconds:", 1, 1, 3600, 1, &ok);
            if (ok) {
                captureDurationTimer3.start(duration * 1000); // Convert seconds to milliseconds
                captureDurationActive3 = true;
                captureDurationButton3.setText("Stop capturing");
            }
        }
    });

    QObject::connect(&captureDurationTimer3, &QTimer::timeout, captureImage3);

    bool captureDurationActive4 = false;
    QTimer captureDurationTimer4;
    QObject::connect(&captureDurationButton4, &QPushButton::clicked, [&]() {
        if (captureDurationActive4) {
            captureDurationTimer4.stop();
            captureDurationActive4 = false;
            captureDurationButton4.setText("Capture every X sec");
        } else {
            // Prompt the user to enter the duration in seconds
            bool ok;
            int duration = QInputDialog::getInt(&window, "Capture Duration", "Enter duration in seconds:", 1, 1, 3600, 1, &ok);
            if (ok) {
                captureDurationTimer4.start(duration * 1000); // Convert seconds to milliseconds
                captureDurationActive4 = true;
                captureDurationButton4.setText("Stop capturing");
            }
        }
    });

    QObject::connect(&captureDurationTimer4, &QTimer::timeout, captureImage4);

    bool captureDurationActive5 = false;
    QTimer captureDurationTimer5;
    QObject::connect(&captureDurationButton5, &QPushButton::clicked, [&]() {
        if (captureDurationActive5) {
            captureDurationTimer5.stop();
            captureDurationActive5 = false;
            captureDurationButton5.setText("Capture every X sec");
        } else {
            // Prompt the user to enter the duration in seconds
            bool ok;
            int duration = QInputDialog::getInt(&window, "Capture Duration", "Enter duration in seconds:", 1, 1, 3600, 1, &ok);
            if (ok) {
                captureDurationTimer5.start(duration * 1000); // Convert seconds to milliseconds
                captureDurationActive5 = true;
                captureDurationButton5.setText("Stop capturing");
            }
        }
    });

    QObject::connect(&captureDurationTimer5, &QTimer::timeout, captureImage5);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    QPushButton openVideoButton("Chose Video", &window);
    openVideoButton.setGeometry(935, 35, 150, 30);
    QObject::connect(&openVideoButton, &QPushButton::clicked, [&]() {
        openVideo(&window);
    });

    QPushButton captureFramesButton("Capture frames", &window);
    captureFramesButton.setGeometry(935, 65, 150, 30);
    QObject::connect(&captureFramesButton, &QPushButton::clicked, [&]() {
        bool ok;
        int captureInterval = QInputDialog::getInt(&window, "Capture Interval", "Enter the capture interval in seconds:", 1, 1, 9999, 1, &ok);
        if (ok) {
            openVideoWithInterval(&window, captureInterval);
        } else {
            QMessageBox::warning(&window, "Invalid Input", "Please enter a valid positive integer for the capture interval.");
        }
    });

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    QPushButton createFolder("Create New Dataset", &window);
    createFolder.setGeometry(780, 35, 150, 30);
    QObject::connect(&createFolder, &QPushButton::clicked, newFolder);

    QPushButton deleteFolderButton("Delete Dataset", &window);
    deleteFolderButton.setGeometry(780, 65, 150, 30);
    QObject::connect(&deleteFolderButton, &QPushButton::clicked, [&]() {
        deleteFolder(&window);
    });

    QPushButton copyFolderButton("Copy Dataset", &window);
    copyFolderButton.setGeometry(780, 95, 150, 30);
    QObject::connect(&copyFolderButton, &QPushButton::clicked, [&]() {
        copyFolder(&window);
    });

    QPushButton mergeButton("Merge Datasets", &window);
    mergeButton.setGeometry(780, 125, 150, 30);
    QObject::connect(&mergeButton, &QPushButton::clicked, [&]() {
        mergeFolders(&window);
    });

    QPushButton processButton("Transform Dataset", &window);
    processButton.setGeometry(780, 155, 150, 30);

    QObject::connect(&processButton, &QPushButton::clicked, &processImages);

    window.show();

    return app.exec();
}